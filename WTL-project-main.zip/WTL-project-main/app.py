from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re

app = Flask(__name__)

db = MySQLdb.connect(
    host = "localhost",
    user = "root",
    passwd = "#root9694",
    database = "SOB"
    )
    
db.autocommit(True)
cursor = db.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS credentials (User_id int AUTO_INCREMENT not null PRIMARY KEY, First_Name varchar(20) not null, Last_Name varchar(20) not null, Email_id varchar(30) UNIQUE not null, Password varchar(10) not null, Role varchar(10) not null Check(Role in ('Admin','Writer','Reader')))")
cursor.execute("CREATE TABLE IF NOT EXISTS writer (User_id int , Writer_id varchar(20) not null PRIMARY KEY, Intro varchar(255) not null, Blog_Titles varchar(50) not null, Social_Media varchar(50) not null, No_of_blogs int(10) not null, FOREIGN KEY (User_id) REFERENCES credentials(User_id)) ")
cursor.execute("CREATE TABLE IF NOT EXISTS blog (Blog_id varchar(20) not null PRIMARY KEY, User_id int , Title varchar(50) not null, Content varchar(50) not null, Image varchar(50), Date_and_time timestamp, Sources varchar(100), Views int, Likes int, FOREIGN KEY (User_id) REFERENCES credentials(User_id))")
cursor.execute("CREATE TABLE IF NOT EXISTS comments (Comment_id varchar(20) not null PRIMARY KEY, User_id int , Description varchar(70) not null, Date_and_time timestamp, FOREIGN KEY (User_id) REFERENCES credentials(User_id))")
#cursor.execute("INSERT INTO credentials (First_Name, Last_Name, Email_id, Password, Role) VALUES (%s,%s,%s,%s,%s)",('Flask','Admin','admin2021@gmail.com', 'admin@123','Admin'))

# IDs coming soon ....

# writer_id = 'w' + User_id
# blog_id = 'b' + User_id
# comment_id = 'c' + User_id



@app.route("/")
def index():
    return render_template('index.html')

@app.route("/blogs/")
def blogs():
    return render_template('blogs.html')

@app.route("/gallery/")
def gallery():
    return render_template('gallery.html')

@app.route("/welcome")
def welcome():
    return render_template('welcome.html')
    
@app.route("/welcome",methods=['POST'])
def welcome_post():
    User_Name = request.form.get('user_name')
    User_Email = request.form.get('user_email')
    User_Query = request.form.get('user_query')
    # Other_Profile = request.form.get('other_profile')
    # Last_name = request.form.get('last_name')
    # User_email = request.form.get('mail')
    # User_password = request.form.get('pwd')

    print(User_Name, User_Email, User_Query)

    #cursor.execute("INSERT INTO credentials (First_Name, Last_Name, Email_id, Password, Role) VALUES (%s,%s,%s,%s,%s)",('rohit','bari',User_email,User_password,'Admin'))
    return render_template('welcome.html')

@app.route("/wannaBeWriter")
def wannaBeWriter():
    return render_template('wantToBeAWriter.html')
    
@app.route("/wannaBeWriter",methods=['POST'])
def wannaBeWriter_post():
    About_Writer = request.form.get('about_writer')
    Linkedin_Profile = request.form.get('linkedin_profile')
    Insta_Profile = request.form.get('insta_profile')
    Other_Profile = request.form.get('other_profile')
    # Last_name = request.form.get('last_name')
    # User_email = request.form.get('mail')
    # User_password = request.form.get('pwd')

    #print(About_Writer, Linkedin_Profile, Insta_Profile, Other_Profile)

    #cursor.execute("INSERT INTO writer (User_id, Writer_id, Intro, Blog_Titles, Social_Media, No_of_blogs) VALUES (%s,%s,%s,%s,%s,%s)",('1','a',About_Writer,'R',Linkedin_Profile,'4'))
    return render_template('uploadblog.html')

@app.route("/reset_password")
def reset_password():
    return render_template('resetpassword.html')
    
@app.route("/reset_password",methods=['POST'])
def reset_password_post():
    Old_Pass = request.form.get('old_pwd')
    New_Pass = request.form.get('new_pwd')
    # Last_name = request.form.get('last_name')
    # User_email = request.form.get('mail')
    # User_password = request.form.get('pwd')

    print(Old_Pass, New_Pass)

    #cursor.execute("INSERT INTO credentials (First_Name, Last_Name, Email_id, Password, Role) VALUES (%s,%s,%s,%s,%s)",('rohit','bari',User_email,User_password,'Admin'))
    return render_template('login.html')

@app.route("/signin")
def signin():
    return render_template('signin.html')
    
@app.route("/signin",methods=['POST'])
def signin_post():
    First_name = request.form.get('first_name')
    Last_name = request.form.get('last_name')
    User_email = request.form.get('mail')
    User_password = request.form.get('pwd')

    print(First_name, Last_name)

    #cursor.execute("INSERT INTO credentials (First_Name, Last_Name, Email_id, Password, Role) VALUES (%s,%s,%s,%s,%s)",(First_name,Last_name,User_email,User_password,'Admin'))
    return render_template({{ url_for('index') }})

@app.route("/upload")
def upload():
    return render_template('uploadblog.html')
    
@app.route("/upload",methods=['POST'])
def upload_post():
    Writer_name = request.form.get('writer_name')
    Introduction = request.form.get('intro')
    Title = request.form.get('blog_title')
    Blog_Img = request.form.get('blog_img')
    Blog_Content = request.form.get('blog_content')
    Blog_Path = request.form.get('blog_path')
    Sources = request.form.get('sources')
    Time_to_read = request.form.get('time_to_read')
    #print(Blog_Img, Blog_Content, Blog_Path, Sources, Time_to_read)
    # cursor.execute("INSERT INTO writer (Writer_id, Intro, Blog_Titles, Social_Media No_of_blogs) VALUES (%s,%s,%s,%s,%s)",('a', Introduction, Title, 'we', '4'))
    # cursor.execute("INSERT INTO blog (Blog_id, Title, Content, Image, Date_and_time, Sources) VALUES (%s,%s,%s,%s,%s,%s)",('a',Title, Blog_Content, Blog_Img, '29-05-2021', Sources))
    # #return render_template('blogs.html')

if __name__ == "__main__":
    # cursor.execute("UPDATE scoreboard SET Tic_Tac_Toe_Single = Tic_Tac_Toe_Single+1 WHERE Username = 'Rohit'")
    app.run(debug=True)

